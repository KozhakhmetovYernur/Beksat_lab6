"""Доступ к данным: демонстрационные товары вместо базы данных."""

from copy import deepcopy

_PRODUCTS = [
    {"id": "mouse", "name": "Беспроводная мышь", "price": "9900.00", "available": True},
    {"id": "keyboard", "name": "Механическая клавиатура", "price": "24900.00", "available": True},
    {"id": "hub", "name": "USB-C хаб", "price": "14900.00", "available": False},
]


def list_products():
    return deepcopy(_PRODUCTS)
