from django.urls import path

from . import views

urlpatterns = [
    path("", views.catalog_screen, name="catalog"),
    path("api/products/", views.products_api, name="products-api"),
]
