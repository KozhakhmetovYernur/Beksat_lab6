from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import ensure_csrf_cookie

from . import services


@ensure_csrf_cookie
def catalog_screen(request):
    return render(request, "catalog/catalog.html", {"products": services.list_products()})


def products_api(request):
    return JsonResponse(
        {"items": services.list_products()}, json_dumps_params={"ensure_ascii": False}
    )
