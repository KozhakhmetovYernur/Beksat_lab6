"""Слой каталога: БП-01 — товар должен быть в наличии."""

from . import repositories


class ProductError(ValueError):
    def __init__(self, code, message, status):
        self.code, self.message, self.status = code, message, status
        super().__init__(message)


def list_products():
    return repositories.list_products()


def purchasable_product(product_id):
    product = next((p for p in list_products() if p["id"] == product_id), None)
    if product is None:
        raise ProductError("PRODUCT_NOT_FOUND", "Товар не найден", 404)
    if not product["available"]:
        raise ProductError("OUT_OF_STOCK", "Товар закончился. Выберите другой товар", 409)
    return product
