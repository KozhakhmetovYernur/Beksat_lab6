"""БП-03: обязательные контактные данные. Пока без сохранения в БД."""

import re


def validate_contact(name, phone, address):
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Введите имя, чтобы оформить заказ")
    if not isinstance(address, str) or len(address.strip()) < 5:
        raise ValueError("Укажите улицу и номер дома для доставки")
    if not isinstance(phone, str) or not re.fullmatch(r"[+0-9 ()-]+", phone):
        raise ValueError("Проверьте номер телефона")
    digits = re.sub(r"[^0-9]", "", phone)
    if len(digits) != 11 or digits[0] not in "78":
        raise ValueError("Проверьте номер телефона, например +7 700 123-45-67")
    return {"name": name.strip(), "phone": "+7" + digits[1:], "address": address.strip()}
