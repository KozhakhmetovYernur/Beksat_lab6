# UC-01 Оформить заказ
Источник: приложенная ЛР №5 Сагимуратова Бекзата.
Э-01 Каталог, Э-02 Товар, Э-03 Корзина, Э-04 Оформление, Э-05 Подтверждение, Э-06 Успех.
БП-01: наличие. БП-02: количество 1–5. БП-03: имя, телефон, адрес.
БП-04: товары + доставка 1000 ₸. БП-05: редактирование до подтверждения.
БП-06: Ожидает обработки после подтверждения.

Проектные операции:
GET /api/products/; GET /api/products/{id}/;
POST /api/cart/items/ {product_id,quantity}; GET /api/cart/;
PUT /api/checkout/draft/ {name,phone,address,payment_method,comment,cart_revision};
POST /api/orders/ {draft_id,confirmed:true,revision} + Idempotency-Key;
GET /api/orders/{id}/.
2а: 409 OUT_OF_STOCK. 3а: GET корзины с 200 items=[], переход в каталог.
Контакты и адрес: 422; отсутствие подтверждения: 400; повтор ключа возвращает прежний заказ.
После успеха: status=WAITING_PROCESSING, status_label=Ожидает обработки.
Платёжный шлюз в исходном UC-01 не указан; фактического списания нет.

Реализованы GET /api/products/ и POST /api/quotes/.
POST /api/quotes/ {items:[{product_id:mouse,quantity:2}]}
-> 200 subtotal=19800.00, shipping=1000.00, total=20800.00, currency=KZT.
Ошибки: 400 INVALID_JSON/INVALID_ITEMS/INVALID_ITEM, 404 PRODUCT_NOT_FOUND,
409 OUT_OF_STOCK, 422 QUANTITY_RANGE/EMPTY_CART; без CSRF при браузерном POST 403.
Количество ограничено суммарно на один товар, повторные строки объединяются.
Расчёт не создаёт заказ и не резервирует товар.
