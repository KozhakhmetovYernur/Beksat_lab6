import json

from django.http import JsonResponse
from django.views.decorators.http import require_POST

from catalog.services import ProductError

from .services import CartError, quote_cart


@require_POST
def quote_api(request):
    try:
        data = json.loads(request.body)
        if not isinstance(data, dict) or "items" not in data:
            return JsonResponse({"error": "INVALID_JSON"}, status=400)
        result = quote_cart(data["items"])
    except (CartError, ProductError) as error:
        return JsonResponse({"error": error.code, "message": error.message}, status=error.status)
    except (ValueError, TypeError):
        return JsonResponse({"error": "INVALID_JSON"}, status=400)
    return JsonResponse(result, json_dumps_params={"ensure_ascii": False})
