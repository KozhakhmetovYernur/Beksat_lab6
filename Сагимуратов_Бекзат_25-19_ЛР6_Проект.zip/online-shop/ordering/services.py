"""Слой логики: БП-02 (1–5 единиц) и БП-04 (доставка 1000 ₸)."""

from decimal import Decimal

from catalog.services import purchasable_product

SHIPPING = Decimal("1000.00")


class CartError(ValueError):
    def __init__(self, code, message, status=422):
        self.code, self.message, self.status = code, message, status
        super().__init__(message)


def quote_cart(items):
    if not isinstance(items, list):
        raise CartError("INVALID_ITEMS", "Передайте список товаров", 400)
    if not items:
        raise CartError("EMPTY_CART", "Корзина пуста. Выберите товар из каталога")
    merged = {}
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get("product_id"), str):
            raise CartError("INVALID_ITEM", "Проверьте идентификатор товара", 400)
        quantity = item.get("quantity")
        if type(quantity) is not int or not 1 <= quantity <= 5:
            raise CartError("QUANTITY_RANGE", "Можно заказать от 1 до 5 единиц")
        pid = item["product_id"]
        merged[pid] = merged.get(pid, 0) + quantity
        if merged[pid] > 5:
            raise CartError("QUANTITY_RANGE", "Суммарно можно заказать до 5 единиц одного товара")
    lines, subtotal = [], Decimal("0.00")
    for pid, quantity in merged.items():
        product = purchasable_product(pid)
        amount = Decimal(product["price"]) * quantity
        lines.append(
            {
                "product_id": pid,
                "name": product["name"],
                "quantity": quantity,
                "unit_price": product["price"],
                "line_total": f"{amount:.2f}",
            }
        )
        subtotal += amount
    return {
        "items": lines,
        "subtotal": f"{subtotal:.2f}",
        "shipping": f"{SHIPPING:.2f}",
        "total": f"{subtotal + SHIPPING:.2f}",
        "currency": "KZT",
    }
