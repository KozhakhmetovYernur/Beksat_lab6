import json
from decimal import Decimal

from django.test import SimpleTestCase

from catalog.services import ProductError
from customers.services import validate_contact
from ordering.services import CartError, quote_cart


class RuleTests(SimpleTestCase):
    def test_total_includes_shipping(self):
        result = quote_cart([{"product_id": "mouse", "quantity": 2}])
        self.assertEqual(Decimal(result["total"]), Decimal("20800.00"))

    def test_shipping_once(self):
        result = quote_cart(
            [{"product_id": "mouse", "quantity": 1}, {"product_id": "keyboard", "quantity": 1}]
        )
        self.assertEqual(result["total"], "35800.00")

    def test_quantity_bounds(self):
        for quantity in [0, 6, 1.5, True]:
            with self.subTest(quantity=quantity), self.assertRaises(CartError):
                quote_cart([{"product_id": "mouse", "quantity": quantity}])

    def test_duplicate_items_cannot_bypass_limit(self):
        with self.assertRaises(CartError):
            quote_cart(
                [{"product_id": "mouse", "quantity": 3}, {"product_id": "mouse", "quantity": 3}]
            )

    def test_out_of_stock(self):
        with self.assertRaises(ProductError) as error:
            quote_cart([{"product_id": "hub", "quantity": 1}])
        self.assertEqual(error.exception.code, "OUT_OF_STOCK")

    def test_empty_cart(self):
        with self.assertRaises(CartError) as error:
            quote_cart([])
        self.assertEqual(error.exception.code, "EMPTY_CART")

    def test_contact_normalization(self):
        result = validate_contact(" Тестовый покупатель ", "+7 700 123-45-67", "ул. Тестовая, 1")
        self.assertEqual(result["phone"], "+77001234567")

    def test_required_contact(self):
        with self.assertRaises(ValueError):
            validate_contact("", "+77001234567", "ул. Тестовая, 1")


class HttpTests(SimpleTestCase):
    def test_catalog_matches_api(self):
        screen, api = self.client.get("/"), self.client.get("/api/products/")
        self.assertEqual(api.status_code, 200)
        for product in api.json()["items"]:
            self.assertContains(screen, product["name"])
        self.assertIn("csrftoken", screen.cookies)

    def test_quote_api(self):
        response = self.client.post(
            "/api/quotes/",
            data=json.dumps({"items": [{"product_id": "mouse", "quantity": 2}]}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["total"], "20800.00")

    def test_invalid_json(self):
        response = self.client.post("/api/quotes/", data="[", content_type="application/json")
        self.assertEqual(response.status_code, 400)

    def test_out_of_stock_api(self):
        response = self.client.post(
            "/api/quotes/",
            data=json.dumps({"items": [{"product_id": "hub", "quantity": 1}]}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 409)
