from django.urls import path

from .views import quote_api

urlpatterns = [path("quotes/", quote_api, name="quote-api")]
